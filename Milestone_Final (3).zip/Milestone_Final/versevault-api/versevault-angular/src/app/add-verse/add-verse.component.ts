import { Component } from '@angular/core';

@Component({
  selector: 'app-add-verse',
  imports: [],
  templateUrl: './add-verse.component.html',
  styleUrl: './add-verse.component.css'
})
export class AddVerseComponent {

}
