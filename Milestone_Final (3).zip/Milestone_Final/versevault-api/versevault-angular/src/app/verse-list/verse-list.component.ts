import { Component } from '@angular/core';

@Component({
  selector: 'app-verse-list',
  imports: [],
  templateUrl: './verse-list.component.html',
  styleUrl: './verse-list.component.css'
})
export class VerseListComponent {

}
