import express from 'express';
import { getVerses, createVerse, updateVerse, deleteVerse } from '../controllers/verseController';

const router = express.Router();
router.get('/', getVerses);
router.post('/', createVerse);
router.put('/:id', updateVerse);
router.delete('/:id', deleteVerse);

export default router;