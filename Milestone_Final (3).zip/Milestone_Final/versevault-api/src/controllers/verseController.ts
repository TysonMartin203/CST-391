import { Request, Response } from 'express';
import { db } from '../config/db';
import { OkPacket } from 'mysql2';

// Get all verses
export const getVerses = (req: Request, res: Response) => {
    db.query('SELECT * FROM verses', (err, results: any) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Database error' });
        }
        res.json(results);
    });
};

// Get one verse by ID
export const getVerse = (req: Request, res: Response) => {
    const { id } = req.params;
    db.query('SELECT * FROM verses WHERE id = ?', [id], (err, results: any) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Database error' });
        }
        if (results.length === 0) {
            return res.status(404).json({ message: 'Verse not found' });
        }
        res.json(results[0]);
    });
};

// Create a new verse
export const createVerse = (req: Request, res: Response) => {
    const { user_id, book, chapter, verse_number, text, category, notes } = req.body;
    db.query(
        'INSERT INTO verses (user_id, book, chapter, verse_number, text, category, notes) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [user_id, book, chapter, verse_number, text, category, notes],
        (err, result) => {
            if (err) {
                console.error(err);
                return res.status(500).json({ error: 'Database error' });
            }
            const okPacket = result as OkPacket;
            res.status(201).json({ message: 'Verse created', verseId: okPacket.insertId });
        }
    );
};

// Update an existing verse
export const updateVerse = (req: Request, res: Response) => {
    const { id } = req.params;
    const { book, chapter, verse_number, text, category, notes } = req.body;
    db.query(
        'UPDATE verses SET book = ?, chapter = ?, verse_number = ?, text = ?, category = ?, notes = ? WHERE id = ?',
        [book, chapter, verse_number, text, category, notes, id],
        (err) => {
            if (err) {
                console.error(err);
                return res.status(500).json({ error: 'Database error' });
            }
            res.json({ message: 'Verse updated' });
        }
    );
};

// Delete a verse
export const deleteVerse = (req: Request, res: Response) => {
    const { id } = req.params;
    db.query('DELETE FROM verses WHERE id = ?', [id], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Database error' });
        }
        res.json({ message: 'Verse deleted' });
    });
};