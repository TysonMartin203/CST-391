import express from 'express';
import verseRoutes from './routes/verseRoutes';
import categoryRoutes from './routes/categoryRoutes';
import sharedRoutes from './routes/sharedRoutes';
import { connectDB } from './config/db';

const app = express();
const PORT = 3000;

app.use(express.json());

connectDB();

app.use('/api/verses', verseRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/shared', sharedRoutes);

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});