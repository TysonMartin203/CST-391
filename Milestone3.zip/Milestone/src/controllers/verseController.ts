import { Request, Response } from 'express';
import { db } from '../config/db';

export const getVerses = (req: Request, res: Response) => {
    db.query('SELECT * FROM verses', (err, results) => {
        if (err) throw err;
        res.json(results);
    });
};

export const getVerse = (req: Request, res: Response) => {
    const { id } = req.params;
    db.query('SELECT * FROM verses WHERE id = ?', [id], (err, results) => {
        if (err) throw err;
        res.json(results[0]);
    });
};

export const createVerse = (req: Request, res: Response) => {
    const { user_id, book, chapter, verse_number, text, category, notes } = req.body;
    db.query(
        'INSERT INTO verses (user_id, book, chapter, verse_number, text, category, notes) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [user_id, book, chapter, verse_number, text, category, notes],
        (err) => {
            if (err) throw err;
            res.json({ message: 'Verse created' });
        }
    );
};

export const updateVerse = (req: Request, res: Response) => {
    const { id } = req.params;
    const { book, chapter, verse_number, text, category, notes } = req.body;
    db.query(
        'UPDATE verses SET book=?, chapter=?, verse_number=?, text=?, category=?, notes=? WHERE id=?',
        [book, chapter, verse_number, text, category, notes, id],
        (err) => {
            if (err) throw err;
            res.json({ message: 'Verse updated' });
        }
    );
};

export const deleteVerse = (req: Request, res: Response) => {
    const { id } = req.params;
    db.query('DELETE FROM verses WHERE id = ?', [id], (err) => {
        if (err) throw err;
        res.json({ message: 'Verse deleted' });
    });
};