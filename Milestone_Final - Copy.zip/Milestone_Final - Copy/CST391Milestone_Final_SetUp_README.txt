VerseVault Milestone Project



Project Structure:

- `versevault-api/` - Backend
- `versevault-angular/` - Angular Frontend
- `versevault-react/` - React Frontend


Setup Instructions:

Backend:

cd versevault-api
npm install
npx tsc
node dist/app.js


Angular:

cd versevault-angular
npm install
ng serve


React:

cd versevault-react
npm install
npm start


*** Need to add back the node modules
*** Might need to change the password as well in config/db.ts