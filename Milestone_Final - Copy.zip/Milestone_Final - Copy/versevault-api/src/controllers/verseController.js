"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteVerse = exports.updateVerse = exports.createVerse = exports.getVerse = exports.getVerses = void 0;
const db_1 = require("../config/db");
// Get all verses
const getVerses = (req, res) => {
    db_1.db.query('SELECT * FROM verses', (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Database error' });
        }
        res.json(results);
    });
};
exports.getVerses = getVerses;
// Get one verse by ID
const getVerse = (req, res) => {
    const { id } = req.params;
    db_1.db.query('SELECT * FROM verses WHERE id = ?', [id], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Database error' });
        }
        if (results.length === 0) {
            return res.status(404).json({ message: 'Verse not found' });
        }
        res.json(results[0]);
    });
};
exports.getVerse = getVerse;
// Create a new verse
const createVerse = (req, res) => {
    const { user_id, book, chapter, verse_number, text, category, notes } = req.body;
    db_1.db.query('INSERT INTO verses (user_id, book, chapter, verse_number, text, category, notes) VALUES (?, ?, ?, ?, ?, ?, ?)', [user_id, book, chapter, verse_number, text, category, notes], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Database error' });
        }
        const okPacket = result;
        res.status(201).json({ message: 'Verse created', verseId: okPacket.insertId });
    });
};
exports.createVerse = createVerse;
// Update an existing verse
const updateVerse = (req, res) => {
    const { id } = req.params;
    const { book, chapter, verse_number, text, category, notes } = req.body;
    db_1.db.query('UPDATE verses SET book = ?, chapter = ?, verse_number = ?, text = ?, category = ?, notes = ? WHERE id = ?', [book, chapter, verse_number, text, category, notes, id], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Database error' });
        }
        res.json({ message: 'Verse updated' });
    });
};
exports.updateVerse = updateVerse;
// Delete a verse
const deleteVerse = (req, res) => {
    const { id } = req.params;
    db_1.db.query('DELETE FROM verses WHERE id = ?', [id], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Database error' });
        }
        res.json({ message: 'Verse deleted' });
    });
};
exports.deleteVerse = deleteVerse;
