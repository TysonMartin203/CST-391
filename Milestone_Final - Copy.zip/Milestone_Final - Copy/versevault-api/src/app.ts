import express from 'express';
import { connectDB } from './config/db';
import verseRoutes from './routes/verseRoutes';

const app = express();
app.use(express.json());

connectDB();
app.use('/api/verses', verseRoutes);

app.listen(3000, () => console.log('Server running on http://localhost:3000'));