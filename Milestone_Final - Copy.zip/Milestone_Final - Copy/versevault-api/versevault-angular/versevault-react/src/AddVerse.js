import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function AddVerse() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    user_id: 1,
    book: '',
    chapter: '',
    verse_number: '',
    text: '',
    category: '',
    notes: ''
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:3000/api/verses', form)
      .then(() => navigate('/'));
  };

  return (
    <div className="container">
      <h2>Add Verse</h2>
      <form onSubmit={handleSubmit}>
        <input className="form-control mb-2" name="book" placeholder="Book" value={form.book} onChange={handleChange} required />
        <input className="form-control mb-2" name="chapter" placeholder="Chapter" value={form.chapter} onChange={handleChange} required />
        <input className="form-control mb-2" name="verse_number" placeholder="Verse Number" value={form.verse_number} onChange={handleChange} required />
        <textarea className="form-control mb-2" name="text" placeholder="Verse Text" value={form.text} onChange={handleChange} required></textarea>
        <input className="form-control mb-2" name="category" placeholder="Category" value={form.category} onChange={handleChange} />
        <textarea className="form-control mb-2" name="notes" placeholder="Notes" value={form.notes} onChange={handleChange}></textarea>
        <button type="submit" className="btn btn-primary">Save Verse</button>
      </form>
    </div>
  );
}

export default AddVerse;
