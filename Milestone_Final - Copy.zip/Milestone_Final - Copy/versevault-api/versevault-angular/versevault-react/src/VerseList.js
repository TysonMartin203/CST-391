import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function VerseList() {
  const [verses, setVerses] = useState([]);

  useEffect(() => {
    loadVerses();
  }, []);

  const loadVerses = () => {
    axios.get('http://localhost:3000/api/verses')
      .then(res => setVerses(res.data));
  };

  const deleteVerse = (id) => {
    axios.delete(`http://localhost:3000/api/verses/${id}`)
      .then(() => loadVerses());
  };

  return (
    <div className="container">
      <h2>My Verses</h2>
      <Link to="/add" className="btn btn-primary mb-3">Add Verse</Link>
      <ul className="list-group">
        {verses.map(v => (
          <li key={v.id} className="list-group-item d-flex justify-content-between align-items-center">
            {v.book} {v.chapter}:{v.verse_number} - {v.text}
            <button onClick={() => deleteVerse(v.id)} className="btn btn-danger btn-sm">Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default VerseList;
