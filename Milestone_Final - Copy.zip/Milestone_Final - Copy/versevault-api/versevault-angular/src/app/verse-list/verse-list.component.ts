import { Component, OnInit } from '@angular/core';
import { VerseService } from '../verse.service';

@Component({
  selector: 'app-verse-list',
  templateUrl: './verse-list.component.html'
})
export class VerseListComponent implements OnInit {
  verses: any[] = [];

  constructor(private verseService: VerseService) {}

  ngOnInit(): void {
    this.getVerses();
  }

  getVerses(): void {
    this.verseService.getVerses().subscribe(data => {
      this.verses = data;
    });
  }

  deleteVerse(id: number): void {
    this.verseService.deleteVerse(id).subscribe(() => {
      this.getVerses(); // Refresh after delete
    });
  }
}
