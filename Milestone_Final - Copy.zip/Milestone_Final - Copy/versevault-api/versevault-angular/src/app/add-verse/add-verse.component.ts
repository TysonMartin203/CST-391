import { Component } from '@angular/core';
import { VerseService } from '../verse.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-verse',
  templateUrl: './add-verse.component.html'
})
export class AddVerseComponent {
  verse = {
    user_id: 1,
    book: '',
    chapter: '',
    verse_number: '',
    text: '',
    category: '',
    notes: ''
  };

  constructor(private verseService: VerseService, private router: Router) {}

  addVerse(): void {
    this.verseService.addVerse(this.verse).subscribe(() => {
      this.router.navigate(['/verses']);
    });
  }
}
