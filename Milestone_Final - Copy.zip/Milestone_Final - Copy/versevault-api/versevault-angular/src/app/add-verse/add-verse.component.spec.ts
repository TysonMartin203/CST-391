import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddVerseComponent } from './add-verse.component';

describe('AddVerseComponent', () => {
  let component: AddVerseComponent;
  let fixture: ComponentFixture<AddVerseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddVerseComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddVerseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
