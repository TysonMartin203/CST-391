import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class VerseService {
  private apiUrl = 'http://localhost:3000/api/verses';

  constructor(private http: HttpClient) {}

  getVerses(): Observable<any> {
    return this.http.get(this.apiUrl);
  }

  getVerse(id: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/${id}`);
  }

  addVerse(verse: any): Observable<any> {
    return this.http.post(this.apiUrl, verse);
  }

  updateVerse(id: string, verse: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, verse);
  }

  deleteVerse(id: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}