import React, { useState } from 'react';
import axios from 'axios';

function AddVerse() {
  const [form, setForm] = useState({
    user_id: 1,
    book: '',
    chapter: '',
    verse_number: '',
    text: '',
    category: '',
    notes: ''
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:3000/api/verses', form)
      .then(() => alert('Verse added!'))
      .catch(err => console.error(err));
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Add a New Verse</h2>
      <input className="form-control mb-2" name="book" placeholder="Book" onChange={handleChange} />
      <input className="form-control mb-2" name="chapter" placeholder="Chapter" onChange={handleChange} />
      <input className="form-control mb-2" name="verse_number" placeholder="Verse Number" onChange={handleChange} />
      <textarea className="form-control mb-2" name="text" placeholder="Verse Text" onChange={handleChange}></textarea>
      <input className="form-control mb-2" name="category" placeholder="Category" onChange={handleChange} />
      <textarea className="form-control mb-2" name="notes" placeholder="Notes" onChange={handleChange}></textarea>
      <button className="btn btn-primary" type="submit">Submit</button>
    </form>
  );
}

export default AddVerse;