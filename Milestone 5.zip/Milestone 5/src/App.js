import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import VerseList from './VerseList';
import AddVerse from './AddVerse';

function App() {
  return (
    <Router>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <Link className="navbar-brand" to="/">VerseVault</Link>
        <div className="collapse navbar-collapse">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item">
              <Link className="nav-link" to="/">My Verses</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/add">Add Verse</Link>
            </li>
          </ul>
        </div>
      </nav>
      <div className="container mt-4">
        <Routes>
          <Route path="/" element={<VerseList />} />
          <Route path="/add" element={<AddVerse />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;