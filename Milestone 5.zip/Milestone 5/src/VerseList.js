import React, { useEffect, useState } from 'react';
import axios from 'axios';

function VerseList() {
  const [verses, setVerses] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3000/api/verses')
      .then(res => setVerses(res.data))
      .catch(err => console.error(err));
  }, []);

  const deleteVerse = (id) => {
    axios.delete(`http://localhost:3000/api/verses/${id}`)
      .then(() => setVerses(verses.filter(v => v.id !== id)))
      .catch(err => console.error(err));
  };

  return (
    <div>
      <h2>Saved Bible Verses</h2>
      <ul className="list-group">
        {verses.map(v => (
          <li key={v.id} className="list-group-item d-flex justify-content-between align-items-center">
            {v.text}
            <button className="btn btn-danger btn-sm" onClick={() => deleteVerse(v.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default VerseList;